# -*- coding: utf-8 -*-

"""Top-level package for sqlalchemy-mongobi."""

__author__ = """Simone Marzola"""
__email__ = 'marzolasimone@gmail.com'
__version__ = '0.2.1'
